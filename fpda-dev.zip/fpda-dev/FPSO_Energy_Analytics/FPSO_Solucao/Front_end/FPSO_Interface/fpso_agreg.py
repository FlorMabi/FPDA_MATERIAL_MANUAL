from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5 import uic
import pandas as pd
import sys
from PyQt5.QtCore import pyqtSignal, QObject


class fpso_agreg(QMainWindow):
    dfChanged = pyqtSignal()
    ## adicionar ao construtor os objetos das combobox para poder adicionar o nome da nova coluna
    ##  combobox.addItem('nome_coluna')
    def __init__(self, df):
        super().__init__()
        uic.loadUi('fpso_pp_agreg_interface.ui', self)
        self.df=df
        agreg_data = list(self.df.columns.values)  # Coletando os dados do data frame para adicionar na combobox
        agreg_data.remove('index')
        self.agreg_var_comboBox.addItems(agreg_data)  # Adicionando os dados na combobox
        self.agreg_Button.clicked.connect(self.pp_agreg)

    def pp_agreg(self):
        """ Modifica dataframe de trabalho ao aplicar as modificacoes selecionadas na janela fpso_agreg """
        self.df[self.agreg_var_lineEdit.text()] = self.df[self.agreg_var_comboBox.currentData()].sum(axis=1)
        self.dfChanged.emit()
        self.close()