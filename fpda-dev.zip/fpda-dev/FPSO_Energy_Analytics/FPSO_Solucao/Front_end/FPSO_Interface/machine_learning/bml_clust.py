"""
Título do Projeto: Sistema inteligente para levantamento dos fatores de uso de
cargas elétricas nos FPSOs correlacionados às demandas de produção
Número de registro do Projeto: 5900.0117579.21.9

Back-end: bc_data
Módulo: Machine Learning
Caso de uso:

Versão 0.11:
Criação do módulo bml_clust
Caso de uso:
Data de Início: 03/02/2023
Data de Entrega para Revisão: 
Data de Release: --/--/----
Nome do Responsável: Vitor Hugo Ferreira
Contato: vhferreira@id.uff.br
Desenvolvedor: Daniel Cunha de Araujo Júnior
Contato: dc_junior@id.uff.br
Caso de teste:
Responsável pelo Teste:
Bloco geral de observações importantes:
    Definida a classe bc_Clust, responsável pela funcionalidade de 
clusterização.

"""

import os
import json
import itertools
import pickle as pkl
import copy

import pandas as pd
import numpy as np
import plotly.express as px


from sklearn.metrics import silhouette_score

from sklearn.cluster import KMeans

import numpy as np
import pandas as pd

# from machine_learning import bml_bbox
# from machine_learning.bml_check import bc_Check
# from machine_learning import bml_model
# from machine_learning import bml_perfm
# from machine_learning import bml_dtmn
# from machine_learning import bml_log


"""
Define a classe bc_Clust, cuja finalidade é oferecer funcionalidades para 
clusterização.

Métodos
----------

 Classe bc_Clust:
 
 bmm_amdls: Retorna uma tupla contendo os nomes dos modelos disponíveis.
 

"""


class bc_Clust:
    """
    Classe bc_Clust, cuja finalidade é oferecer funcionalidades para 
    clusterização.

    Métodos públicos:
        bc_clust

    """

    @staticmethod
    def bc_clust(
            bc_data: pd.DataFrame = None,
            bc_cnint: tuple = (3, 10),
            bc_nvar: int = 3,
            bc_natol: object = 0.1,
            bc_wsw: object = 0,
    ) -> tuple:
        """
        Aplica a clusterização em um dataset fornecido. Recebe, principamente,
        o dataset, o intervalo de busca para quantidade de clusters e o número de 
        variáveis para visualização. Retorna tupla contendo o dataset adicionado de 
        colunas indicando os clusters, tupla contendo o melhor conjunto de variáveis 
        encontrado para visualização, figura gerada automaticamente, melhor número 
        de clusters encontrado e respectivos silhouette score e weighted silhouette score.

        :param bc_data: Dataframe contendo o dataset.
        :param bc_cnint: Tupla contendo o intervalo [a,b] de números de clusters a ser 
        procurado.
        :param bc_nvar: Número de variáveis a serem utilizadas para visualizar 
        a clusterização (2 ou 3).
        :param bc_natol: tolerancia para colunas com valores NaN. [0, 1]
        :param bc_wsw: Peso para numeros de clusters grandes. Quanto maior, maior a 
        preferencia por clusterizações com poucos clusters.  
        
        :return: Tupla contendo contendo o dataset adicionado de 
        colunas indicando os clusters, tupla contendo o melhor conjunto de variáveis 
        encontrado para visualização, figura gerada automaticamente, melhor número 
        de clusters encontrado e respectivos silhouette score e weighted silhouette 
        score. Em caso de exceção retornará None.

        """

        try: 
            # deep copy
            bc_data = bc_data.copy()
            
            # percentual de nans por coluna
            bc_nanp = 100*bc_data.isna().sum()/len(bc_data) 
            # print(bc_nanp)

            # remover colunas que nao atendem ao percentual
            bc_data = bc_data[[bc_col for bc_col in bc_data.columns.to_list() if 100*bc_natol > bc_nanp[bc_col]]]
            bc_nnanp = 100*bc_data.isna().sum()/len(bc_data)
            # print(bc_nnanp)

            # remove rows with nans
            bc_data = bc_data.loc[bc_data.notna().all(1)]

            # intervalo da quantidade de clusters a ser considerada
            bc_rnc = range(min(bc_cnint), max(bc_cnint)+1)
            
            # melhor numero de clusters
            bc_bnc = 0 
            # melhor silhouette score
            bc_bsil = -10
            # melhor weighted silhouette score
            bc_bws = -10
            for bc_nc in bc_rnc:
                # Kmeans
                bc_kmean = KMeans(n_clusters=bc_nc, random_state=10)
                
                # labels
                bc_clab = bc_kmean.fit_predict(bc_data)
                # print(bc_clab)

                # 'silhouette score' -> metrica de intervalo [-1,1] que indica qualidade da clusterizacao (densidade e separacao).  
                bc_sil = silhouette_score(bc_data, bc_clab)
                bc_wsil = (bc_sil+1)/(2*(1 + bc_wsw*bc_nc))
                print(f"Para {bc_nc} clusters o silhouette score é {bc_sil} e o weighted silhouette score é {bc_wsil}")
                if bc_wsil > bc_bws:
                    bc_bws = bc_wsil # melhor weighted score
                    bc_bsil = bc_sil # melhor silhouette score
                    bc_bnc = bc_nc # melhor numero de clusters
                    bc_bclab = [*bc_clab] # melhores labels de clusters
                    # print(f'best number of cluster: {bc_bnc}')


            print(f'melhor numero de clusters: {bc_bnc}')
            bc_data['cluster'] = bc_bclab
            # print(bc_data.corr()['cluster'].drop('cluster'))

            # binning dos clusters
            for i in np.unique(bc_data['cluster']):
                bc_data[f'cluster_{i}'] = (bc_data['cluster'] == i).astype(int)

            # correlacao entre cada variável do dataset e o cada cluster
            bc_corr = bc_data.corr()[[f'cluster_{i}' for i in range(bc_bnc)]].drop(labels=['cluster']).drop(labels=[f'cluster_{i}' for i in range(bc_bnc)])
            # remover NaNs
            bc_corr = bc_corr.loc[bc_corr.notna().all(1)]
            # print(bc_corr)

            # em valores absolutos (sao desejadas correlações =/= 0, nao importa o sinal)
            bc_acorr = abs(bc_corr)

            # Escolhendo o mehor conjunto para visualizacao por heuristica
            print(bc_acorr)
            bc_c = bc_acorr.sum(1).sort_values(ascending=False).head(3).index.to_list()
            bc_bestv = (bc_acorr.loc[[*bc_c]].sum().mean(), bc_c, bc_acorr.loc[[*bc_c]].sum())

            # convertendo 'cluster' para string (para visualizacao)
            bc_cdata = bc_data.copy()
            bc_cdata['cluster'] = bc_cdata['cluster'].astype(str)

            # tomando a melhor opcao para visualizacao

            # geracao da figura automatica
            if bc_nvar == 3:
                bc_fig = px.scatter_3d(bc_cdata, x=bc_bestv[1][0], y=bc_bestv[1][1], z=bc_bestv[1][2], color='cluster', title='Clusterização')
                # bc_fig.show()
            else:
                bc_fig = px.scatter(bc_cdata, x=bc_bestv[1][0], y=bc_bestv[1][1], color='cluster', title='Clusterização')
                # bc_fig.show()

            return bc_cdata, bc_c, bc_fig, bc_bnc, bc_bsil, bc_bws

        except Exception as ex:
            
            print("Exceção em bc_clust: ", ex)
            # raise ex
            return None